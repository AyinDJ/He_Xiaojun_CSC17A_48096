/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Weather.h
 * Author: Jimmy
 *
 * Created on October 4, 2016, 4:49 PM
 */

#ifndef WEATHER_H
#define WEATHER_H

struct Weather {
    int total;//total rainfall
    int high;//high temperature
    int low;//low temperature
    float average;//average temperature
};




#endif /* WEATHER_H */

