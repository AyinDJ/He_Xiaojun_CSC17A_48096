/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   speaker.h
 * Author: Jimmy
 *
 * Created on October 4, 2016, 11:19 PM
 */

#ifndef SPEAKER_H
#define SPEAKER_H

struct Speaker {
    string name;
    string number;//phone number
    string speTopc;//speaking topic
    int fee;//fee required
};

#endif /* SPEAKER_H */

