/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SaleData.h
 * Author: Jimmy
 *
 * Created on October 4, 2016, 2:02 PM
 */

#ifndef SALEDATA_H
#define SALEDATA_H

struct Sales{
    string name;
    float first;
    float second;
    float third;
    float fourth;
    float total;
    float average;
};


#endif /* SALEDATA_H */

