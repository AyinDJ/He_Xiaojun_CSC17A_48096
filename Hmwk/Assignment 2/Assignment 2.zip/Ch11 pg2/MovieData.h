/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MovieData.h
 * Author: Jimmy
 *
 * Created on October 4, 2016, 12:27 PM
 */

#ifndef MOVIEDATA_H
#define MOVIEDATA_H

struct MovieData{
    string title;
    string dirc;
    unsigned short yearrel;
    unsigned short runtime;
    float cost;
    float reve;
};

#endif /* MOVIEDATA_H */

