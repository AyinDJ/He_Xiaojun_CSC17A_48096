/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   class.h
 * Author: Jimmy
 *
 * Created on October 4, 2016, 11:59 PM
 */

#ifndef CLASS_H
#define CLASS_H

struct Student {
    string name;//student name
    string id;//student id
    int *score;//pointer to an array of scores
    float ave;//average of score
    char grade;//course grade
};

#endif /* CLASS_H */

