var searchData=
[
  ['othello',['Othello',['../class_othello.html',1,'']]],
  ['othello_2ecpp',['Othello.cpp',['../_othello_8cpp.html',1,'']]],
  ['othello_2eh',['Othello.h',['../_othello_8h.html',1,'']]]
];
