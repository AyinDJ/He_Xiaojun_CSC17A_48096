var searchData=
[
  ['win',['win',['../class_othello.html#aa988281f6c8107e7d078de68e9ae9d3d',1,'Othello']]]
];
