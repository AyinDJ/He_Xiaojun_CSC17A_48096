var searchData=
[
  ['change1',['change1',['../class_othello.html#ae0203712ad7067ace03879191aa3c187',1,'Othello']]],
  ['change2',['change2',['../class_othello.html#ad98cd8ba030a4900155b7bbe1a36de98',1,'Othello']]],
  ['clear',['clear',['../class_othello.html#ae6fcfc01ad3e23ec98cdfd5f67208cb3',1,'Othello']]],
  ['counter',['counter',['../class_othello.html#ac12d9682f956e7fedf9e120c71a35c59',1,'Othello']]]
];
