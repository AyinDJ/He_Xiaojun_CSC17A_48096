var searchData=
[
  ['judge1',['judge1',['../class_othello.html#ae3d4f0fb9d242449b1cdf6adb0816016',1,'Othello']]],
  ['judge2',['judge2',['../class_othello.html#abaa0a512973fc53bc75c9cae3ca4f478',1,'Othello']]]
];
