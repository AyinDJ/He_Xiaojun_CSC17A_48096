var searchData=
[
  ['othello',['Othello',['../class_othello.html',1,'']]]
];
