var searchData=
[
  ['start',['start',['../class_othello.html#afbd303f619ad4aa032aac05745f333cd',1,'Othello']]]
];
