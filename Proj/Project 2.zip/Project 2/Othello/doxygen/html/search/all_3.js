var searchData=
[
  ['num',['num',['../class_othello.html#a2cb68488152c90c5cfc916b62333d3b1',1,'Othello']]]
];
